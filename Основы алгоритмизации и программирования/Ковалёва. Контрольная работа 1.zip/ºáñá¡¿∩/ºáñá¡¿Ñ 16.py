input_str = " Смотри ,    открыли новый магазин!   "
normalized_str = input_str.replace('  ', ' ').strip()
print(normalized_str)  
