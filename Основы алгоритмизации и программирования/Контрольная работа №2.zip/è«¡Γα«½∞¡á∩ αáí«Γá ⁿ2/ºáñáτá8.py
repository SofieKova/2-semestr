num = float(input("Введите число: "))
result = num ** 2

print(f"Квадрат этого числа равен {result}.")
