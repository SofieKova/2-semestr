x = 10
y = 20
z = x + y

local_vars = locals()
local_variables_count = len(local_vars)

print(f"Количество локальных переменных: {local_variables_count}")
