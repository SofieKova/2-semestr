input_string = "зелёный-красный-жёлтый-черный-чёрный-белый"
words = input_string.split('-')
sorted_words = sorted(words) 
output_string = '-'.join(sorted_words)

print(output_string)