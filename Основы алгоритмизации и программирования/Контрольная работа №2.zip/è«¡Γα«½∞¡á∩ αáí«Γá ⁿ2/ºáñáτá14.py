numbers = [3, 5, 2, 8, 1]  
max_number = numbers[0]

for number in numbers:
    if number > max_number:  
        max_number = number  

print("Максимальный элемент списка:", max_number)
