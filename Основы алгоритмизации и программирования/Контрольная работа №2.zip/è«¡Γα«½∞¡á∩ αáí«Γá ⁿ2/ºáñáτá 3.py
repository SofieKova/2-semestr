sqares = [x**2 for x in range(1, 31)]

print(sqares)