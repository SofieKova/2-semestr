def outer_function(x):
    def inner_function(y):
        return y ** 2
    
    result = inner_function(x)
    return result + 5

result = outer_function(3)

print(result)