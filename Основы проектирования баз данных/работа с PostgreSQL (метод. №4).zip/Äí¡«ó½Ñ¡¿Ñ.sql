update requests
set status='completed'
where id=1;