SELECT FirstName, LastName
FROM Drimm
UNION SELECT FirstName, LastName FROM Raaap;