update posts
set tags='{"sql", "postgres", "database"}'
where id=1;
