SELECT FirstName, CreatedAt, ProductCount, Price
FROM Thh RIGHT JOIN Jim
ON Jim.ThhId=Thh.Id;